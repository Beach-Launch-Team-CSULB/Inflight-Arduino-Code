var searchData=
[
  ['sensor_0',['Sensor',['../class_sensor.html',1,'Sensor'],['../class_sensor.html#a19f71ed1109bcd686facd5d8dc0fafc9',1,'Sensor::Sensor()']]],
  ['sensor_5fstruct_1',['Sensor_struct',['../struct_sensor__struct.html',1,'']]],
  ['setfile_2',['setFile',['../class_sensor.html#ab1289d06386c8b264c3dec43c4544e56',1,'Sensor']]],
  ['setstate_3',['setState',['../class_detection.html#af63740d8ad4772a88808460cd1ae8ba6',1,'Detection']]],
  ['settime_4',['setTime',['../struct_sensor__struct.html#a7c8879301b4cf39b8de8c10a0252c63a',1,'Sensor_struct::setTime()'],['../struct_sensor__struct.html#a69c250dce189f492a9dd20a631e37479',1,'Sensor_struct::setTime(time_t unix_t, uint32_t millis, uint32_t micros)']]]
];
