var searchData=
[
  ['eventlog_0',['EventLog',['../class_event_log.html',1,'']]],
  ['eventlog_5fstruct_1',['eventlog_struct',['../structeventlog__struct.html',1,'']]]
];
