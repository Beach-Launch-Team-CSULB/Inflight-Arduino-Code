var searchData=
[
  ['updatedata_0',['updateData',['../struct_b_m_p.html#a92626cb81a56cd289b28577fe2ffc363',1,'BMP::updateData()'],['../class_event_log.html#a535d7c16496e7fdbaba47a91185bb3b8',1,'EventLog::updateData()'],['../class_i_c_m.html#a98ea51691e216c78b40f6223a97b0a8b',1,'ICM::updateData()'],['../struct_internal_temp.html#ab71eb1aae59a1ebb958022574b1155b3',1,'InternalTemp::updateData()'],['../class_sensor.html#a49e03657e98d76dd40ef7dcbd81cfe08',1,'Sensor::updateData()']]],
  ['updatedetection_1',['updateDetection',['../class_detection.html#a664d1e00ae6041eafcb536f302ca53ec',1,'Detection']]]
];
