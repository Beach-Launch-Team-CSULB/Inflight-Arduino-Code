var searchData=
[
  ['data_5fstruct_5fptr_0',['data_struct_ptr',['../class_sensor.html#a7d62c00363f6891b085adc042c1098ab',1,'Sensor']]],
  ['data_5fstruct_5fsize_1',['data_struct_size',['../class_sensor.html#a52010ac57011fc08adc10e227f699241',1,'Sensor']]],
  ['detection_2',['Detection',['../class_detection.html',1,'Detection'],['../class_detection.html#a86e6ebf5a660a29e78ee7a7f08292260',1,'Detection::Detection()']]],
  ['divider_5fcounter_3',['divider_counter',['../class_sensor.html#a015d86c534dc90ffbf140ea34a3c952b',1,'Sensor']]],
  ['dumptofile_4',['dumpToFile',['../class_sensor.html#a5bbe55e24152987d3a08bd03c2a15834',1,'Sensor']]]
];
