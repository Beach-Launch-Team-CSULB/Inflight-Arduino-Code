var searchData=
[
  ['new_5fdata_5fupdate_0',['new_data_update',['../class_sensor.html#a46d00a0a3e29cd7ff29e16fa7ba58392',1,'Sensor']]]
];
