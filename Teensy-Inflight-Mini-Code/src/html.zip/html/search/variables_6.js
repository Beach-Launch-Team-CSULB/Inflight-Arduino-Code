var searchData=
[
  ['unix_5ftime_0',['unix_time',['../struct_sensor__struct.html#a5cd79fe619435b655a783c7660146408',1,'Sensor_struct']]],
  ['update_5frate_1',['update_rate',['../class_sensor.html#a0efe6c677f0f76b1e08488b749981565',1,'Sensor']]]
];
