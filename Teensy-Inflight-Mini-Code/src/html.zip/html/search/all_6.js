var searchData=
[
  ['name_0',['name',['../class_sensor.html#a9cf70c3e41501d89f6f9f48a3e9d1296',1,'Sensor']]],
  ['new_5fdata_5fupdate_1',['new_data_update',['../class_sensor.html#a46d00a0a3e29cd7ff29e16fa7ba58392',1,'Sensor']]]
];
