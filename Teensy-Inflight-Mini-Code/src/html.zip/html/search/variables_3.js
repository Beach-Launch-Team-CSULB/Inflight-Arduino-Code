var searchData=
[
  ['microseconds_0',['microseconds',['../struct_sensor__struct.html#aeddb485cdd3851647959e860ca89ad5a',1,'Sensor_struct']]],
  ['milliseconds_1',['milliseconds',['../struct_sensor__struct.html#ac2694d67168d24563af5a61a34f21ec7',1,'Sensor_struct']]]
];
