var searchData=
[
  ['detection_0',['Detection',['../class_detection.html#a86e6ebf5a660a29e78ee7a7f08292260',1,'Detection']]],
  ['dumptofile_1',['dumpToFile',['../class_sensor.html#a5bbe55e24152987d3a08bd03c2a15834',1,'Sensor']]]
];
