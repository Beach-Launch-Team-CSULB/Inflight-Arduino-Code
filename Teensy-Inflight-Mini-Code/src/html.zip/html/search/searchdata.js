var indexSectionsWithContent =
{
  0: "bdegimnostuw",
  1: "bdeis",
  2: "degnstuw",
  3: "bdemnou"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables"
};

