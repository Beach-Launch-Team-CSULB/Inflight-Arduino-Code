var searchData=
[
  ['sensor_0',['Sensor',['../class_sensor.html#a19f71ed1109bcd686facd5d8dc0fafc9',1,'Sensor']]],
  ['setfile_1',['setFile',['../class_sensor.html#ab1289d06386c8b264c3dec43c4544e56',1,'Sensor']]],
  ['setstate_2',['setState',['../class_detection.html#af63740d8ad4772a88808460cd1ae8ba6',1,'Detection']]],
  ['settime_3',['setTime',['../struct_sensor__struct.html#a7c8879301b4cf39b8de8c10a0252c63a',1,'Sensor_struct::setTime()'],['../struct_sensor__struct.html#a69c250dce189f492a9dd20a631e37479',1,'Sensor_struct::setTime(time_t unix_t, uint32_t millis, uint32_t micros)']]]
];
