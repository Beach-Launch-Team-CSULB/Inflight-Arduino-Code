var searchData=
[
  ['data_5fstruct_5fptr_0',['data_struct_ptr',['../class_sensor.html#a7d62c00363f6891b085adc042c1098ab',1,'Sensor']]],
  ['data_5fstruct_5fsize_1',['data_struct_size',['../class_sensor.html#a52010ac57011fc08adc10e227f699241',1,'Sensor']]],
  ['divider_5fcounter_2',['divider_counter',['../class_sensor.html#a015d86c534dc90ffbf140ea34a3c952b',1,'Sensor']]]
];
