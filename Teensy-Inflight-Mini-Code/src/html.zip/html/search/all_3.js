var searchData=
[
  ['get_5ftime_0',['get_time',['../struct_sensor__struct.html#abc60e02e47543554baf06d4781ff6e46',1,'Sensor_struct']]],
  ['get_5ftime_5fhdr_1',['get_time_hdr',['../struct_sensor__struct.html#ab64f6135a6d3034f909dec9a67d8f310',1,'Sensor_struct']]],
  ['getheader_2',['getHeader',['../structbmp__struct.html#a7a25377644fa3629a7129ba0dfd6ca99',1,'bmp_struct::getHeader()'],['../structeventlog__struct.html#afed3a9e5b13481c3c5a55a293d730421',1,'eventlog_struct::getHeader()'],['../structicm__struct.html#ac16b5921e89cfc887f7771769a12a89e',1,'icm_struct::getHeader()'],['../structinternal__temp__struct.html#a09ad2ce67940df3d7135eacc3f04acb2',1,'internal_temp_struct::getHeader()'],['../struct_sensor__struct.html#aad34dcd9941948595749b24cfba4fd3d',1,'Sensor_struct::getHeader()']]],
  ['getname_3',['getName',['../class_sensor.html#a60ec96ed03660b42681c1bcc99007033',1,'Sensor']]],
  ['getstate_4',['getState',['../class_detection.html#aa5f5d1cbda9406d0cda3cd2085beb58f',1,'Detection']]]
];
