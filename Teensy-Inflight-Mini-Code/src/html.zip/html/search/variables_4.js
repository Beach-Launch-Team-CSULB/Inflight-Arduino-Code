var searchData=
[
  ['name_0',['name',['../class_sensor.html#a9cf70c3e41501d89f6f9f48a3e9d1296',1,'Sensor']]]
];
